<?php

ini_set('display_errors','On');
error_reporting(E_ALL);

$niz = [-1,8,7,-12];
echo (max(array_map(function($element){
    return abs($element);
},$niz)));

echo '<br>';

function svakoDrugo($string){
    $novistring = '';
    for($i=0;$i<strlen($string);$i+=2){
        $novistring .= $string[$i];
    }
    echo $novistring;
}

svakoDrugo('abcdef');

echo '<br>';

$string = 'Akfjdsbg kdjgfdnfkjasnf';

$niz = [1,5,4,7,98,2,1,4];
print_r($leva = array_slice($niz,0,count($niz)-2));
echo '<br>';
print_r($desna = array_slice($niz,count($niz)-2));
echo '<br>';

function obimKruga($poluprecnik){
    if($poluprecnik<=0){
        throw new Exception("Poluprecnik ne moze da bude manje od 0. <br>");
    }
    return 2*$poluprecnik*pi();
}

//echo obimKruga(-1);

try {
    echo obimKruga(-1) . "<br>";
} catch (Exception $e) {
    echo 'Caught exception: ',  $e->getMessage(), "<br>";
}

echo obimKruga(13);
echo '<br>';

function provera($niz, $string, $broj){
    if(gettype($string)!=='string'){
        throw new Exception('Treba da bude string.');
    }
    if(gettype($broj)!=='integer' && gettype($broj)!='double'){
        throw new Exception('Treba da bude broj.');
    }
    foreach($niz as $element){
        if($string === $element){
            echo 'parametar2 se nalazi u nizu.';
        } elseif($broj === $element){
            echo 'parametar3 se nalazi u nizu.';
        }
    }
}

try{
    echo provera([1,5,2],2,3);
} catch(Exception $e){
    echo 'Caught exception: ',  $e->getMessage(), "<br>";
}

try{
    echo provera([1,5,2],'fsg','fg');
} catch(Exception $e){
    echo 'Caught exception: ',  $e->getMessage(), "<br>";
}
provera([1,5,2],'fsg',2);