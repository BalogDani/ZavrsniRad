<?php
    ini_set('display_errors','On');
    error_reporting(E_ALL);
    //echo '<br>';
    // $ime = $_GET['ime'];
    // $prezime = $_GET['prezime'];

    $cars = [
        [
            'brand'=>'mercedes',
            'type'=>'diesel',
            'manifacture_year' => 2015
        ],
        [
            'brand'=>'peugeot',
            'type'=>'diesel',
            'manifacture_year' => 2015
        ],
        [
            'brand'=>'opel',
            'type'=>'petroleum',
            'manifacture_year' => 2020
        ],
    ];
    $godina = $_GET['year'];
    $tip = $_GET['type'];
    $filteredCars = array_filter($cars, function($car){
        global $godina,$tip;
        if($tip === $car['type'] && $godina == $car['manifacture_year']){
            return $car['brand'];
        }
    });
?>

<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Pagea Titulo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link rel="stylesheet" type="text/css" media="screen" href="main.css" /> -->
    <!-- <script src="main.js"></script> -->
</head>
<body>
    <!-- <?php
        echo "<p>Ime: $ime</p>";
        echo "<p>Prezime: $prezime</p>";
        echo '<br>';
    ?> -->
    <h2>Godina proizvodnje: <?php echo $godina ?></h2>
    <h2>Tip: <?php echo $tip ?></h2>
    <ul>
        <?php
            foreach($filteredCars as $car){
                // var_dump($tip === $car['type'] && $godina === $car['manifacture_year']);
                // echo '<br>';
                // var_dump($car['type'], $car['manifacture_year']);
                // echo '<br>';
                // var_dump($tip,$godina);
                $brand = $car['brand'];
                echo "<li>$brand</li>";
            }
        ?>
    </ul>
</body>
</html>