<?php
    // ako su mysql username/password i ime baze na vasim racunarima drugaciji
    // obavezno ih ovde zamenite
    $servername = "127.0.0.1";
    $username = "root";
    $password = "vivify";
    $dbname = "zadnji";
    try {
        $connection = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        // set the PDO error mode to exception
        $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    catch(PDOException $e)
    {
        echo $e->getMessage();
    }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="favicon.ico">
    <title>Vivify Academy Blog - Homepage</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body class="va-l-page va-l-page--single">
<?php include('header.php'); ?>
    <div class="va-l-container">
        <main class="va-l-page-content">
            <?php
                //ovde pisite upite
            ?>
                    <article class="va-c-article">
                        <header>
                            <h1>Naslov Oglasa</h1>
                            <!-- zameniti privremenu kategoriju pravom kategorijom blog post-a iz baze -->
                            <h3>category: <strong>Kategorija oglasa</strong></h3>
                            <!-- zameniti  datum i ime sa pravim imenom i datumom blog post-a iz baze -->
                            <div class="va-c-article__meta">20.11.2020 by John Doe</div>
                        </header>
                        <!-- zameniti ovaj privremeni (testni) text sa pravim sadrzajem blog post-a iz baze -->
                        <div>
                            <p>Sadrzaj oglasa</p>
                        </div>
                    </article>
        </main>
    </div>
    <?php include('footer.php'); ?>
</body>
</html>