<?php
  $servername = "127.0.0.1";
    $username = "root";
    $password = "vivify";
    $dbname = "zadnji";
    try {
        $connection = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        // set the PDO error mode to exception
        $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    catch(PDOException $e)
    {
        echo $e->getMessage();
    }
    
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="favicon.ico">
  <title>Vivify Academy Blog - Homepage</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body class="va-l-page va-l-page--homepage">]
  <form action="/create_new_profile.php" method="POST">
    <label for="first_name">First name: </label><br>
    <input type="text" id="first_name" name="first_name"><br>
    <label for="last_name">Last name: </label><br>
    <input type="text" id="last_name" name="last_name"><br><br>
    <label for="date_of_birth">Date of Birth: </label><br>
    <input type="text" id="date_of_birth" name="date_of_birth"><br><br>
    <label for="phone">Phone: </label><br>
    <input type="text" id="phone" name="phone"><br><br>
    <label for="city">City: </label><br>
    <input type="text" id="city" name="city"><br><br>
    <input type="submit" value="Submit">
  </form>
</body>
<?php 
  if (isset($_POST['email'])) {
    try {
        $str = "INSERT INTO profiles (id, first_name, last_name, date_of_birth, phone, city, user_id)
    VALUES (null, ?, ?, ?, ?, ?, null);";
    $statement = $connection->prepare($str);
    // izvrsavamo upit
    $statement->execute([$_POST['first_name'],$_POST['last_name'],$_POST['date_of_birth'],$_POST['phone'],$_POST['city']]);
    }
    catch(PDOException $e)
    {
        echo $e->getMessage();
    }
    
  }
?>
</html>