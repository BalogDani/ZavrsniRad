<?php
  $email = $_POST['email'];
  $passw = $_POST['password'];
  $servername = "127.0.0.1";
    $username = "root";
    $password = "vivify";
    $dbname = "zadnji";
    try {
        $connection = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        // set the PDO error mode to exception
        $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    catch(PDOException $e)
    {
        echo $e->getMessage();
    }
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="favicon.ico">
  <title>Vivify Academy Blog - Homepage</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body class="va-l-page va-l-page--homepage">]
  <form action="/create_new_user.php" method="POST">
    <label for="email">Email:</label><br>
    <input type="text" id="email" name="email"><br>
    <label for="password">Password</label><br>
    <input type="text" id="password" name="password"><br><br>
    <input type="submit" value="Submit">
  </form>
</body>
<?php 
  if (isset($_POST['email'])) {
    // ovde saljite upit
    $str = "INSERT INTO `users` (`id`, `email`, `password`) VALUES (null, '$email', '$passw')";
    $statement = $connection->prepare($str);
    // izvrsavamo upit
    $statement->execute();

  }
?>
</html>