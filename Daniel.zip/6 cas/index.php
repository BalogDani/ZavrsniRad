<?php
    // ini_set('display_errors','On');
    // error_reporting(E_ALL);
    $name = $_POST['name'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $website = $_POST['website'];

    function required($type){
        if($_SERVER['REQUEST_METHOD']==='POST'){
            if(!$type){
                echo $type . ' is required.';
            }
        }
    }

    function eMail($email){
        if($_SERVER['REQUEST_METHOD']==='POST'){
            $positionAt = strpos($email,"@");
            $positionDot = strpos($email,".");
            if(!$positionAt && !$positionDot){
                echo "e-mail treba da sadrzi @ i .";
            }
            if($positionAt>$positionDot){
                echo "@ treba da stoji pre .";
            }
        }
    }

    function validWebsite($website){
        if($_SERVER['REQUEST_METHOD']==='POST'){
            if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$website)) {
                echo "Invalid URL"; 
            }
        }
    }

    function checkTheName($name){
        if($_SERVER['REQUEST_METHOD']==='POST'){
            if(!ctype_alpha(str_replace(' ', '', $name))){
                echo "Name should only contains letters.";
            }
        }
    }
?>

<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Our website</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script> -->
</head>
<body>
    <form action="\index.php" method="POST">
        <p style="color:red">* is required</p>
        Name: <input type="text" name="name"> <span style="color:red">* <?php required($name); checkTheName($name);?></span>
        <br><br>
        E-mail: <input type="text" name="email"> <span style="color:red">* <?php required($email); eMail($email);?></span>
        <br><br>
        Website: <input type="text" name="website"> <span style="color:red"> <?php validWebsite($website); ?></span>
        <br><br>
        Comment: <textarea name="comment" rows="5" cols="40"></textarea>
        <br><br>
        Gender:<input type="radio" name="gender" value="female">Female
        <input type="radio" name="gender" value="male">Male <span style="color:red">* <?php required($gender);?></span>
        <br><br>
        <input type="submit" name="submit" value="Submit">
    </form>
    <h2>Your Inputs</h2>
    <?php 
        echo $name . "<br>";
        echo $email;
    ?>
</body>
</html>