<?php

function nasumicneBrojeve ($a, $b) {
    echo rand($a,$b) . "<br>";
}

nasumicneBrojeve(5,500);

function korenBrojeve($niz){
    $koren = [];
    foreach ($niz as $broj){
        array_push($koren, sqrt($broj));
    }
    var_dump($koren);
}

korenBrojeve([4,16,9]);

echo "<br>";

function korenBrojeveZaokruzeno($niz){
    $noviniz = [];
    foreach ($niz as $broj){
        array_push($noviniz, ceil(\sqrt($broj)));
    }
    var_dump($noviniz);
}

korenBrojeveZaokruzeno([2,4,5,8,9]);

echo "<br>";

function transformacijaRecenice($recenica){
    echo strtoupper($recenica);
    echo "<br>";
    echo strtolower($recenica);
    echo "<br>";
    echo ucfirst(strtolower($recenica));
}

transformacijaRecenice('RJVJjbcksdRNdbDmc.');

echo "<br>";

function username($email){
    echo strstr($email,'@',true);
    echo "<br>";
    echo strstr($email,'@');
}
username('ana@gmail.com');

echo "<br>";
function najduzi($string){
    $words = explode(' ',$string);
    $max = '';
    foreach($words as $rec){
        if(strlen($rec)>strlen($max)){
            $max = $rec;
        }
    }
    echo $max;
}
najduzi('fdsag fdsag fgdgg hg jighjihkj');

echo "<br>";

function najduziIndex($niz){
    echo count($niz)-1;
}
najduziIndex([1 ,4 ,5 ,7]);

echo "<br>";

function najveciAbsolutni($niz){
    $najveci = abs($niz[0]);
    foreach($niz as $broj){
        if(abs($broj)>abs($najveci)){
            $najveci = $broj;
        }
    }
    echo $najveci;
}
najveciAbsolutni([4,5,-3,6,-7]);