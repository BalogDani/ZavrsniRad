// console.log("Yo!");
// array1 = ["Banana" ,"Orange"];
// array2 = ["Apple","Mangocart"];
// function elementi(array){
//     array.forEach(element => {
//         console.log(element);
//     });
// }
// elementi(array1);

// function nova(array1, array2){
//     return array1.concat(array2)
//             .filter(function(element){
//                 return element.length >= 6;
//             })
//             .forEach(function(element){
//                 console.log(element);
//             })
//     };
// console.log(nova(array1,array2));

voce = "Apple, Banana, Kiwi";
console.log(voce.substring(7,13));

voce = ['apple', 'banana', 'strawberry', 'orange'];
console.log(voce.reduce(function(max, current){
    if(current.length>max.length){
        return current;
    }
    return max;
}));

var string = "Hello world!";
console.log(string.toUpperCase());
console.log(string.toLowerCase());

var broj = 12.6567;
console.log(broj.toFixed(0));
console.log(broj.toFixed(2));
console.log(broj.toFixed(6));

var stringovi = ["1234", "1234.8", "10 Apples", "John"];
stringovi.forEach(element => {
    console.log(parseInt(element));
});
// console.log(parseInt(stringovi[0]));

function spajanje(prvi, drugi){
    console.log(prvi + drugi);
    
}
function saConcatom(prvi, drugi){
    console.log(prvi.concat(drugi));
    
}
spajanje('dsagfh','fdsbjgk');
saConcatom('dsagfh','fdsbjgk');

obj = {
    firstName: 'asd',
    lastName: 'vfdh',
    age: 30
};
console.log(obj['firstName'], obj.lastName, obj.age);

obj = {firstName: 'John', lastName: 'Doe'};
console.log(obj.firstName[0], obj.lastName[0]);

niz = ["Audi", "BMW", "Fiat", "Ford"];
spojena = niz[0];
for(var i=1; i<niz.length; i++){
    spojena += "/" + niz[i];
}
console.log(spojena);

