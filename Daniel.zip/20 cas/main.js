function parniBrojevi(array){
    var niz = [];
    array.forEach(element => {
        if(element%2 === 0){
            niz.push(element);
        }        
    });
    return niz;
}

function getEven(array, callback){
    return callback(array);
}

console.log(getEven([1,2,3,4,5,6], parniBrojevi));

var person = {
    firstName: 'John',
    lastName: 'Doe',
    yearOfBirth: 1990,
    school: 'NaN',
    occupation: 'dealer'
};
person.fullName = function() {
    return this.firstName + ' ' + this.lastName
};
person.in2050IWillBe = function() { return 2050 - this.yearOfBirth; };

console.log(person.fullName());
console.log(person.in2050IWillBe());

function doubleNumber(n){
    return 2*n;
}
console.log(doubleNumber(5));

// Napisati funkciju humanToDogYears, koja prima starost u godinama N, i vraca starost u psećim godinama (koja je 7 puta veća).
function humanToDogYears(N){
    return 7*N;
}

// Napisati funkciju celsiusToFahrenheit koja prima temperaturu u stepenima Celzijusa (°C) i vraća odgovarajuću temperaturu u stepenima Farenhajta (°F). Formula za konverziju je sledeća: [°F] = [°C] × ​9⁄5 + 32.
function celsiusToFahrenheit(cels){
    return cels *9 / 5 +32;
}
console.log(celsiusToFahrenheit(0));

// Napisati funkciju fahrenheitToCelsius, koja prima temperaturu u stepenima Farenhajta (°F) i vraća odgovarajuću temperaturu u stepenima Celzijusa (°C). Formula za konverziju je [°C] = ([°F] − 32) × ​5⁄9

function fahrenheitToCelsius(farenh){
    return (farenh - 32)*5/9;
}
console.log(fahrenheitToCelsius(0));

// Funkciju dogAge iz drugog zadatka napisati kao anonimnu funkciju i smestiti je u promenljivu anonymousDogAge.
var anonymousDogAge = function (N){
    return 7*N;
}
console.log(anonymousDogAge(7));

// Napisati funkciju koja prima proizvoljni niz i ispisuje njegove elemente, uvećane za 1, pomoću forEach.
function elementiNiza(niz){
    var noviNiz = [];
    niz.forEach(function(element){
        noviNiz.push(element + 1);
    });
    return noviNiz;
}
console.log(elementiNiza([1,23,4,5,3]));

// Napisati funkciju koja prima dva niza, array1 i array2, i poziva forEach na prvom pa na drugom nizu, pritom koristeći kao callback istu funkciju (ne treba pisati dva puta isti kod za callback).
function dvaNiza(array1, array2, callback){
    return '[' + callback(array1) + '] i [' + callback(array2) + ']';
}
console.log(dvaNiza([14,8,6],[7,4,-2,-6,0],elementiNiza));

// Napisati funkciju koja prima proizvoljni niz i neki broj N, i ispisuje elemente niza, uvećane za N, pomoću forEach.
function povecanoSaN(niz,N){
    var noviNiz = niz.map(element => element + N)
    return noviNiz;
}
console.log(povecanoSaN([1,2,3],3));
