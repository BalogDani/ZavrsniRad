function Racun(brojRacuna, banka, vlasnik, stanje) {
    this.brojRacuna = brojRacuna;
    this.banka = banka;
    this.vlasnik = vlasnik;
    this.stanje = stanje;
  }
function Banka(ime){
    this.ime = ime;
    this.racuni = [];
    this.dodajRacun = function (vlasnik, pocetnoStanje, brojRacuna){
        var racun  = new Racun(brojRacuna, this, vlasnik, pocetnoStanje);
        this.racuni.push(racun);
        return racun;
    }
}

var banka = new Banka('Don');
var racun  = banka.dodajRacun('Pero', 100, 's6g54dsg34');
console.log(racun, banka);

var image = new Image(180,150);
image.src = 'http://amolife.com/image/images/stories/Animals/cute_kitten_12.jpg';
document.body.appendChild(image);
console.log(image);

function Vozilo(tip){
    this.tip = tip;
    this.vozi = function () {
        console.log('Vozi Misko');
    }
}
var vozilo1 = new Vozilo('Kamion');
function Automobil(){
    Vozilo.call(this, 'Automobil');
}
var automobil1 = new Automobil();
console.log(automobil1);

function Cetvorougao(a, b, c, d){
    this.a = a;
    this.b = b;
    this.c = c;
    this.d = d;
}
Cetvorougao.prototype.izracunajObim = function(){
    return this.a+this.b+this.c+this.d;
}
function Pravougaonik(a,b){
    Cetvorougao.call(this, a, b, a, b);
}

Pravougaonik.prototype = Object.create(Cetvorougao.prototype);
Object.defineProperty(Pravougaonik.prototype, 'construktor', {
    value: Pravougaonik,
    writable: true,
    enumerable: false
})

Pravougaonik.prototype.izracunajPovrsinu = function(){
    return this.a*this.b;
}

var pravougaonik = new Pravougaonik(4,5);
console.log(pravougaonik.izracunajPovrsinu());

console.log(pravougaonik);

