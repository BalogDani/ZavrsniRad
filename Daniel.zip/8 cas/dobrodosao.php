<?php
    ini_set('display_errors','On');
    error_reporting(E_ALL);
?>

<style>
    * {
        box-sizing: border-box;
    }
    body{
        width: 100%;
        height: 100%;
    }
    header{
        padding: 10px;
        border: 2px;
        border-style: solid;
        border-color: black;
    }
    div{
        width: 100%;
        display: flex;
        justify-content: space-around;  
    }
    h1{
        height: 300px;
        text-align: center;
        border: 2px;
        margin: 0;
        border-style: solid;
        border-color: black;
    }
    footer{
        padding: 10px;
        border: 2px;
        border-style: solid;
        border-color: black;
        text-align: center;
    }
</style>

<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dobro dosao</title>
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script> -->
</head>
<body>
    <header>
        <div>
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        </div>
    </header>
    <h1>Dobro dosao!</h1>
    <footer>
        <p>‘Sva prava zadržana’, <?php echo date('Y');?></p>
    </footer>
</body>
</html>