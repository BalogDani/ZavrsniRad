<?php
    ini_set('display_errors','On');
    error_reporting(E_ALL);

    include_once('functions.php');
    if($_SERVER['REQUEST_METHOD'] === 'GET') {
        $users = read();
        foreach($users as $element){
            $user = explode('-', $element);
            print_r($user);
            echo '<br>';
        }
    }
?>
<style>
    * {
        box-sizing: border-box;
        margin: 0;
    }
    body{
        width: 100%;
        height: 100%;
    }
    header{
        padding: 10px;
        border: 2px;
        border-style: solid;
        border-color: black;
    }
    div{
        width: 100%;
        display: flex;
        justify-content: space-around;  
    }
    form{
        height: 300px;
        text-align: center;
        border: 2px;
        margin: 0;
        border-style: solid;
        border-color: black;
    }
    footer{
        padding: 10px;
        border: 2px;
        border-style: solid;
        border-color: black;
        text-align: center;
    }
</style>

<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script> -->
</head>
<body>
    <header>
        <div>
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        </div>
    </header>
    <form action="login.php" method="POST">
        <h1>Register</h1>
        <p>Ime: <input type="text" name="ime" placeholder="Joe" required/></p>
        <p>Prezime: <input type="text" name="prezime" placeholder="Big" required/></p>
        <p>Email: <input type="email" name="email" placeholder='joe.big@gmail.com'></p>
        <p>Lozinka: <input type="text" name="password" placeholder='nonono'></p>
        <input type="submit" name="submit" value="Registruj se">
    </form>
    <footer>
        <p>‘Sva prava zadržana’, <?php echo date('Y');?></p>
    </footer>
</body>
</html>