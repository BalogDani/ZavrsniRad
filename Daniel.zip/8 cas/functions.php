<?php
    $file = 'users.txt';
    function read() {
        global $file;
        $fh = fopen($file, 'r');
        $myFileContents = fread($fh, filesize($file));
        fclose($fh);
        if (!$myFileContents) {
            return [];
        }
        $users = explode(PHP_EOL, $myFileContents);
        return $users;
    }
    function write ($newContents) {
        global $file;
        $myFileLink2 = fopen($file, 'a') or die("Can't open file.");
        fwrite($myFileLink2, "$newContents\n");
        fclose($myFileLink2);
    }
    // write("Marina Marinic");
    // print_r(read());
?>