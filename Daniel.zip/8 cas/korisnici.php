<?php
    ini_set('display_errors','On');
    error_reporting(E_ALL);

    session_start();

    include_once('functions.php');


    if(!isset($korisnici)){
        $korisnici=[];
    }

    $users = read();
    foreach($users as $element){
        $user = explode('-', $element);
        print_r($user);
        echo '<br>';
        $noviKorisnik = [
            'ime' => $user[2],
            'prezime' => $user[3],
            'email' => $user[0],
            'password' => $user[1]
        ];
        array_push($korisnici,$noviKorisnik);
        if($_POST['email']===$noviKorisnik['email']){
            $actualName = $noviKorisnik['ime'];
            $actualSurName = $noviKorisnik['prezime'];
            echo $actualName;
        }
    }

    print_r($korisnici);
?>
<style>
    * {
        box-sizing: border-box;
        margin: 0;
    }
    body{
        width: 100%;
        height: 100%;
    }
    header{
        padding: 10px;
        border: 2px;
        border-style: solid;
        border-color: black;
    }
    div{
        width: 100%;
        display: flex;
        justify-content: space-around;  
    }
    form{
        height: 300px;
        text-align: center;
        border: 2px;
        margin: 0;
        border-style: solid;
        border-color: black;
    }
    footer{
        padding: 10px;
        border: 2px;
        border-style: solid;
        border-color: black;
        text-align: center;
    }
</style>

<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script> -->
</head>
<body>
    <header>
        <div>
            <p>Dobro dosao, <?php echo $actualName . ' ' . $actualSurName;?></p>
        </div>
    </header>
    <h1>Ovo su svi korisnici</h1>
    <ul>
        <?php 
            foreach($korisnici as $korisnik){
                $ime = $korisnik['ime'];
                $prezime = $korisnik['prezime'];
                echo "<p>$ime $prezime</p>";
            }
        ?>
    </ul>

    <footer>
        <p>‘Sva prava zadržana’, <?php echo date('Y');?></p>
    </footer>
</body>
</html>