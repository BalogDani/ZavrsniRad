<?php
    ini_set('display_errors','On');
    error_reporting(E_ALL);

    session_start();

    if($_SERVER['REQUEST_METHOD'] ==='POST'){
        $_SESSION['username'] = $_POST['username'];
        $_SESSION['password'] = $_POST['password'];
    }

    if(!isset($_SESSION['username']) || !isset($_SESSION['password'])){
        header('Location: index.php');
    }

    $username = $_SESSION['username'];
    $password = $_SESSION['password'];
?>

<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script> -->
</head>
<body>
    <form action="/home.php" method="POST">
        <h1>Welcome to the app!</h1>
        <p>User: <?php $username?> with password: <?php $password?></p>
        <p>Dodaj auta:</p>
        <a href="add-cars.php">Ovde</a>
    </form>
</body>
</html>