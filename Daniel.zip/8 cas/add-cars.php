<?php
    ini_set('display_errors','On');
    error_reporting(E_ALL);

    session_start();

    if(!isset($_SESSION['cars'])){
        $_SESSION['cars']=[];
    }

    if($_SERVER['REQUEST_METHOD'] ==='POST'){
        $newCar = [
            'brend' => $_POST['brend'],
            'model' => $_POST['model'],
            'power' => $_POST['power'],
            'manifacture_year' => $_POST['manifacture_year']
        ];
    }

    array_push($_SESSION['cars'],$newCar);

    $cars = $_SESSION['cars'];
?>

<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script> -->
</head>
<body>
    <form action="/add-cars.php" method="POST">
        <h1>Dodaj novi auto:</h1>
        <p><?php $username?> with password: <?php $password?></p>
        <p>Brend: <input type="text" name="brend" placeholder="Mercedes" required/></p>
        <p>Model: <input type="text" name="model" placeholder="A1" required/></p>
        <p>Snaga motora: <input type="text" name="power" placeholder='2800'></p>
        <p>Godina proizvodnje: <input type="text" name="manifacture_year" placeholder='2010'></p>
        <input type="submit" name="submit" value="Dodaj">
    </form>

    <ul>
        <?php 
            foreach($cars as $car){
                $brend = $car['brend'];
                $model = $car['model'];
                $power = $car['power'];
                $manifactureYear = $car['manifacture_year'];
                echo "<p>Auto</p>";
                echo "<p>Brend: $brend</p>";
                echo "<p>Model: $model</p>";
                echo "<p>Snaga motora: $power</p>";
                echo "<p>Godina proizvodnje: $manifactureYear</p>";
            }
        ?>
    </ul>
</body>
</html>