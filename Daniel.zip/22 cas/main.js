var request = new XMLHttpRequest();
request.addEventListener('load', function (event) {
  console.log('cao, evo ti response');
  var obj = JSON.parse(event.currentTarget.response);
  var data = obj.data;
  console.log(data);
  if (data) {
    data.forEach(element => {
        userDataDiv = document.getElementById('userData');
        userDataDiv.innerHTML  = '<p>'+ element.employee_name + ' ' + element.employee_salary + '</p>';
    });
  } else {
    alert("Zaposleni sa id-em 11241asdasd nije tu");
  }
});

request.open('GET', 'https://dummy.restapiexample.com/api/v1/employees');
request.send();
console.log('Zadnja linija');

