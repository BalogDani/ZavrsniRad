<?php
    ini_set('display_errors','On');
    error_reporting(E_ALL);

    class Animal{
        public $name = "God";
        public function speak(){
            echo "Argh!";
        }
        public function __construct($name)
        {
            $this->name = $name;
        }
    }
    class Dog extends Animal{
        public $what;
        public function bark(){
            echo $this->speak() . " Woof!!!";
        }
        public function __construct($name, $what = "Nooo!")
        {
            parent::__construct($name);
            $this->what = $what;
        }
    }

    // $animani = new Animal();
    // $dogibogi = new Dog();
    // $dogibogi->name = "Cuko";
    //echo '<pre>'; var_dump($animani instanceof Dog); echo '</pre>';
    //echo '<pre>'; var_dump($animani instanceof Animal); echo '</pre>';

    function dump($stvar){
        echo '<pre>'; var_dump($stvar); echo '</pre>';
    }
    // dump($animani);
    // dump($animani->speak());
    // dump($dogibogi);
    // dump($dogibogi->bark());


    class Vozilo{
        public $tezina;
        public $nosivost;
        public $vrstaKretanja;
        public function __construct($tezina, $nosivost, $vrstaKretanja)
        {
            $this->tezina = $tezina;
            $this->nosivost = $nosivost;
            $this->vrstaKretanja = $vrstaKretanja;
        }
    }
    class MotornoVozilo extends Vozilo{
        public $kubikaza;
        public $vrstGoriva;
        public function kreni(){
            echo "Brm";
        }
    }
    class Automobil extends MotornoVozilo{
        protected $brojVrata;
    }
    class Autobus extends MotornoVozilo{
        public $brojSedista;
    }
    class Motocikl extends MotornoVozilo{
        public $sirinaGuma;
        public function kreni(){
            echo "150 km/h";
        }
    }
    class Limuzina extends Automobil{
        public $duzinaLimuzina;
        public function vratici(){
            return $this->brojVrata;
        }
        public function kreni(){
            echo "!$@?";
        }
    }
    class Bicikl extends Vozilo{
        public $brojSiceva;
        public function __construct($tezina, $nosivost, $vrstaKretanja, $brojSiceva = 200)
        {
            parent::__construct($tezina, $nosivost, $vrstaKretanja);
            $this->brojSiceva = $brojSiceva;
        }
    }

    // $motor1 = new Motocikl();
    // $auto1 = new Automobil();
    // $limo1 = new Limuzina();
    // $bajs1 = new Bicikl();

    // //echo '<pre>'; var_dump($auto1); echo '</pre>';
    // echo '<pre>'; var_dump($limo1); echo '</pre>';
    // //echo '<pre>'; var_dump($bajs1); echo '</pre>';
    
    // $motor1->kreni();
    // echo "<br>";
    // $auto1->kreni();
    // echo "<br>";
    // $limo1->kreni();
    $doggy = new Dog("Pajti");
    dump($doggy);

    $bajsi = new Bicikl(1500, 200, "dobra");
    dump($bajsi);
    
    class Disk {
        public $ime;
        public $memorija;
        public $lista_foldera = [];
        public function __construct($ime, $memorija)
        {
            $this->ime = $ime;
            $this->memorija = $memorija;
        }
        public function dodajFolder($folder)
        {
            $this->lista_foldera[] = $folder;
        }
    }
    class Folder {
        public $ime;
        public $lista_fajlova = [];
        public function __construct($ime)
        {
            $this->ime = $ime;
        }
        public function dodajFajl($fajl)
        {
            $this->lista_fajlova[] = $fajl;
        }
    }
    class Fajl {
        public $ime;
        public function __construct($ime)
        {
            $this->ime = $ime;
        }
    }
    class Video extends Fajl {
        public $format;
        public function __construct($ime, $format)
        {
            parent::__construct($ime);
            $this->format = $format;
        }
    }
    class Slika extends Fajl {
        public $sirina;
        public $visina;
        public function __construct($ime, $sirina, $visina)
        {
            parent::__construct($ime);
            $this->sirina = $sirina;
            $this->visina = $visina;
        }
    }
    class TekstualniFajl extends Fajl {
        public $duzinaTeksta;
        public function __construct($ime, $duzinaTeksta)
        {
            parent::__construct($ime);
            $this->duzinaTeksta = $duzinaTeksta;
        }
    }
    $cDisk = new Disk('c', 5000);
    $folderSlike = new Folder('Slike');
    $folderVideo = new Folder('Video');
    $folderText = new Folder('Text');
    $cDisk->dodajFolder($folderSlike);
    $cDisk->dodajFolder($folderVideo);
    $cDisk->dodajFolder($folderText);
    $slika1 = new Slika('Leto 2017', 800, 600);
    $slika2 = new Slika('Leto 2016', 800, 600);
    $folderSlike->dodajFajl($slika1);
    $folderSlike->dodajFajl($slika2);
    $video1 = new Video('Utakmica', 'mp4');
    $folderVideo->dodajFajl($video1);
    $textualniFajl1 = new TekstualniFajl('Dokument1', 3000);
    $textualniFajl2 = new TekstualniFajl('Dokument2', 5000);
    $folderText->dodajFajl($textualniFajl1);
    $folderText->dodajFajl($textualniFajl2);
    dump($cDisk);

    class Osoba{
        public $ime;
        public $prezime;
        public function __construct($ime, $prezime){
            $this->ime = $ime;
            $this->prezime = $prezime;
        }
    }
    class Ordinacija extends Grad{
        public $adresa;
        public $doktori = [];
        public function __construct($ime, $adresa)
        {
            parent::__construct($ime);
            $this->adresa = $adresa;
        }
        public function dodajDoktora($doktor)
        {
            $this->doktori[] = $doktor;
        }
    }
    class Doktor extends Osoba{
        public $sestre = [];
        public $pacijenti = [];
        public $specijalizacija;
        public function __construct($ime, $prezime, $sestra){
            parent::__construct($ime, $prezime);
            $this->sestre[] = $sestra;
        }
        public function dodajSestre($sestra)
        {
            $this->sestre[] = $sestra;
        }
        public function dodajPacijenta($pacijent)
        {
            $this->pacijenti[] = $pacijent;
        }
        public function dodajPregleda($jedanPacijent, $pregled)
        {
            foreach($this->pacijenti as $pacijent){
                if($pacijent===$jedanPacijent){
                    $pacijent->pregled = $pregled;
                }
            }
        }
        public function dodajRecepta($jedanPacijent, $recept)
        {
            foreach($this->pacijenti as $pacijent){
                if($pacijent===$jedanPacijent){
                    $pacijent->recept = $recept;
                }
            }
        }
    }
    class Sestra extends Osoba{
        public $doktor;
        public function dodajDoktora($doktor)
        {
            $this->doktor = $doktor;
        }
    }
    class Pacijent extends Osoba{
        public $doktor;
        public $pregled;
        public $recept;
        public function izaberiDoktora($doktor)
        {
            $this->doktor = $doktor;
        }

    }
    class Pregled{
        public $datum;
        public function __construct($datum){
            $this->datum = $datum;
        }
    }
    class Grad{
        public $imeGrada;
        public function __construct($ime){
            $this->imeGrada = $ime;
        }
    }
    class Specijalizacija{
        public function dodajSpecijalizaciju($doktor, $specijalizacija){
            $doktor->specijalizacija = $specijalizacija;
        }
    }
    class Recept{
        public $terapija;
        public function __construct($terapija){
            $this->terapija = $terapija;
        }
    }
?>