<?php
    ini_set('display_errors','On');
    error_reporting(E_ALL);

    function dump($stvar){
        echo '<pre>';
        var_dump($stvar);
        echo '</pre>';
    }
    abstract class Osobja
    {
        public $ime;
        public $prezime;
        public function __construct(string $ime, string $prezime)
        {
            $this->ime = $ime;
            $this->prezime = $prezime;
        }
    }
    class Doktor extends Osobja
    {
        public $specijalnost;
        public $pacijenti = [];
        public function __construct(string $ime, string $prezime, string $specijalnost)
        {
            parent::__construct($ime, $prezime);
            $this->specijalnost = $specijalnost;
            echo "Kreiran je doktor $this->ime $this->prezime. <br/>";
        }
        public function zakaziPregled(Pregled $pregled)
        {
            echo "Zakazan je pregled $pregled->tip za pacijenta {$pregled->pacijent->ime} {$pregled->pacijent->prezime} kod doktora $this->ime $this->prezime.<br/>";
        }
    }
    class Pacijent extends Osobja
    {
    public $jmbg;
    public $brojKartona;
    public $doktor;
    public function __construct(string $ime, string $prezime, string $jmbg, string $brojKartona)
    {
        parent::__construct($ime, $prezime);
        $this->jmbg = $jmbg;
        $this->brojKartona = $brojKartona;
        echo "Kreiran je pacijent $this->ime $this->prezime. <br/>";
    }
    public function izaberiLekara(Doktor $doktor)
    {
            $this->doktor = $doktor;
            $this->doktor->pacijenti[] = $this;
            echo "Pacijent $this->ime je izabrao lekara {$this->doktor->ime } {$this->doktor->prezime}. <br/>";
    }
    }
    abstract class Pregled
    {
    public $datum;
    public $vreme;
    public $pacijent;
    public $tip;
    public function __construct(string $datum, string $vreme, Pacijent $pacijent, string $tip)
    {
        $this->datum = $datum;
        $this->vreme = $vreme;
        $this->pacijent = $pacijent;
        $this->tip = $tip;
    }
    public abstract function obaviPregled();
    }
    class PregledKrvniPritisak extends Pregled
    {
    public $gornjaVrednost;
    public $donjaVrednost;
    public $puls;
    public function __construct(string $datum, string $vreme, Pacijent $pacijent)
    {
            parent::__construct($datum, $vreme, $pacijent, 'krvni pritisak');
    }
    public function obaviPregled()
    {
            echo "Obavi pregled krvog pritiska za pacijenta {$this->pacijent->ime} {$this->pacijent->prezime}. <br/>";
            $this->gornjaVrednost = 120;
            $this->donjaVrednost = 80;
            $this->puls = 60;
            echo "Rezultati pregleda: pritisak je {$this->gornjaVrednost}/{$this->donjaVrednost}, puls je $this->puls. <br/>";
            echo "Pacijent {$this->pacijent->ime} je obavio pregled $this->tip. <br/>";
    }
    }
    class PregledNivoSecera extends Pregled
    {
    public $vrednost;
    public $vremePoslednjegObroka;
    public function __construct(string $datum, string $vreme, Pacijent $pacijent)
    {
        parent::__construct($datum, $vreme, $pacijent, 'nivo secera');
    }
    public function obaviPregled()
    {
            echo "Obavi pregled nivoa secera u krvi za pacijenta {$this->pacijent->ime} {$this->pacijent->prezime} <br/>";
            $this->vrednost = 40;
            $this->vremePoslednjegObroka = '08:56';
            echo "Rezultati pregleda: vrednost $this->vrednost, vreme poslednjeg obroka $this->vremePoslednjegObroka <br/>";
            echo "Pacijent {$this->pacijent->ime} je obavio pregled {$this->tip}. <br/>";
            Loger::logujObnavljanjePregleda($this);
    }
    }
    class PregledHolesterol extends Pregled
    {
        public $vrednost;
        public $vremePoslednjegObroka;
        public function __construct(string $datum, string $vreme, Pacijent $pacijent)
        {
            parent::__construct($datum, $vreme, $pacijent, 'nivo holesterola');
        }
        public function obaviPregled()
        {
            echo "Obavi pregled holesterola za pacijenta {$this->pacijent->ime} {$this->pacijent->prezime} <br/>";
            $this->vrednost = 40;
            $this->vremePoslednjegObroka = '08:56';
            echo "Rezultati pregleda: vrednost $this->vrednost, vreme poslednjeg obroka $this->vremePoslednjegObroka <br/>";
            echo "Pacijent " . $this->pacijent->ime . " je obavio pregled" . $this->tip . "<br/>";
            
        }
    }
    // $docMilan = new Doktor('Milan', 'Milanovic', 'kardiolog');
    // $pacDragan = new Pacijent('Dragan', 'Jovanovic', '023342323', '0005677');
    // $pacDragan->izaberiLekara($docMilan);
    // $pregled1 = new PregledNivoSecera('12-12-2017', '08:00', $pacDragan);
    // $docMilan->zakaziPregled($pregled1);
    // $pregled2 = new PregledKrvniPritisak('12-12-2017', '08:15', $pacDragan);
    // $docMilan->zakaziPregled($pregled2);
    // $pregled1->obaviPregled();
    // $pregled2->obaviPregled();
    // dump($pregled1);
    class Loger{
        static public function logujKreiranjeDoktora(Doktor $doktor){
            
        }
        static public function logujKreiranjePacijenta(Pacijent $pacijent){

        }
        static public function logujBiranjeLekara(Pacijent $pacijent, Doktor $doktor){

        }
        static public function logujObnavljanjePregleda( $pregled){
            echo (new DateTime())->format('d.m.Y H:i') . " Pacijent" . $pregled->pacijent->ime . " izvrsio je laboratorijski pregled nivoa: " . $pregled->tip;
        }
    }

    class Kompanija
{
   public $ime;
   public $sektori = [];
   public function __construct(string $ime)
   {
       $this->ime = $ime;
       echo "Kreirana je kompanija $this->ime <br/>";
   }
   public function dodajSektor(Sektor $sektor, $kolicina)
   {
       for($i=0; $i<$kolicina; $i++){
            $this->sektori[] = $sektor;
            echo "Dodat je sektor {$this->sektori[$i]->ime} <br/>";
       }
   }
}
abstract class Sektor
{
   public $ime;
   public $zaposleni = [];
   public function __construct(string $ime)
   {
       $this->ime = $ime;
       echo "Kreiran je sektor $this->ime <br/>";
   }
   public function dodajZaposlenog(Zaposleni $zaposleni)
   {
       $this->zaposleni[] = $zaposleni;
       echo "Dodat je nov zaposleni. <br/>";
   }
}
class Fabrika extends Sektor implements DefinisanjeStriktnogRadnogVremena
{
   public $radnoVreme = [];
   public $proizvodi = [];
   public function setRadnoVreme(int $od, int $do)
   {
       $this->radnoVreme = [
           'od' => $od,
           'do' => $do
       ];
       echo "U fabrici je postavljeno radno vreme od {$this->radnoVreme['od']} do {$this->radnoVreme['do']} . <br/>";
   }
   public function dodajProizvod(string $proizvod, int $broj = 1)
   {
       if (!isset($this->proizvodi[$proizvod])) {
           $this->proizvodi[$proizvod] = 0;
       }
       $this->proizvodi[$proizvod] += $broj;
       echo "U fabriku je dodato novih proizvoda: {$this->proizvodi[$proizvod]} <br/>";
   }
}
class ProdajnoMesto extends Sektor implements PravilaOblacenja, DefinisanjeStriktnogRadnogVremena
{
   public $praviloOblacenjaProdajnogMesta;
   public $radnoVreme;
   public $proizvodi = [];
   public function setPraviloOblacenja(string $pravilo)
   {
       $this->praviloOblacenjaProdajnogMesta = $pravilo;
   }
   public function getPraviloOblacenja(): string
   {
       return $this->praviloOblacenjaProdajnogMesta;
   }
   public function setRadnoVreme(int $od, int $do)
   {
       $this->radnoVreme = $od . ' - '. $do;
   }
   public function prodaj(Kupac $kupac, array $proizvodi)
   {
       foreach ($proizvodi as $proizvod) {
           if (!empty($this->proizvodi[$proizvod])) {
               $this->proizvodi[$proizvod]--;
               echo "$proizvod prodat kupcu $kupac->ime <br/>";
           } else {
               echo "$proizvod nema na lageru <br/>";
           }
       }
   }
   public function dodajProizvod(string $proizvod, int $broj = 1)
   {
       if (!isset($this->proizvodi[$proizvod])) {
           $this->proizvodi[$proizvod] = 0;
       }
       $this->proizvodi[$proizvod] += $broj;
       echo "Na prodajno mesto je dodato novih proizvoda: {$this->proizvodi[$proizvod]} <br/>";
   }
}
class OdsekZaNabavke extends Sektor implements ZakazivanjeSastanaka
{
   public $sastanci = [];
   public function zakazatiSastanak(string $datum, string $vreme, string $kontakt)
   {
       $this->sastanci[] = [
           'datum' => $datum,
           'vreme' => $vreme,
           'kontakt' => $kontakt
       ];
       echo "U sektoru nabavke zakazan je sastanak za {$this->sastanci[0]['kontakt']}. <br/>";
   }
}
class OdsekZaMarketing extends Sektor implements PravilaOblacenja, ZakazivanjeSastanaka
{
   public $praviloOblacenja;
   public $sastanci = [];
   public function setPraviloOblacenja(string $pravilo)
   {
       $this->praviloOblacenja = $pravilo;
       echo "U sektor marketing dodato je pravilo oblacenja: $pravilo. <br/>";
   }
   public function getPraviloOblacenja(): string
   {
       return $this->praviloOblacenja;
   }
   public function zakazatiSastanak(string $datum, string $vreme, string $kontakt)
   {
       $this->sastanci[] = "$datum $vreme $kontakt";
   }
}
interface PravilaOblacenja
{
   public function setPraviloOblacenja(string $pravilo);
   public function getPraviloOblacenja(): string;
}
interface ZakazivanjeSastanaka
{
   public function zakazatiSastanak(string $datum, string $vreme, string $kontakt);
}
interface DefinisanjeStriktnogRadnogVremena
{
   public function setRadnoVreme(int $od, int $do);
}
class Osoba
{
   public $ime;
   public $prezime;
   public function __construct(string $ime, string $prezime)
   {
       $this->ime = $ime;
       $this->prezime = $prezime;
   }
}
class Zaposleni extends Osoba
{
}
class Kupac extends Osoba
{
    public $prozivod;
    public function kupi($proizvod){

    }
}
    $kompanija = new Kompanija('BenKomp');
    $fabrika = new Fabrika('Fabro');
    $kompanija->dodajSektor($fabrika, 4);
    // dump($kompanija);

    class Hotel{

    }
    class Soba{
        public $brojSobe;
        public $brojKreveta;
        public $cena;
        public $zauzeta = false;
        public function __construct($brojSobe, $brojKreveta, $cena){
            $this->brojSobe = $brojSobe;
            $this->brojKreveta = $brojKreveta;
            $this->cena = $cena;
        }
    }
    class Hotel{
        public $sobe = [];
        public function dodajSobu(Soba $soba){
            $this->sobe[] = $soba;
        }
        public function pronadji($n){
            foreach($sobe as $soba){
                if($soba->brojKreveta<=$n){
                    $cenaSobe = $soba->cena;
                    $brojSobe = $soba->brojSobe;
                }
            }
        }
    }
?>