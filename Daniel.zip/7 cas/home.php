<?php
    ini_set('display_errors','On');
    error_reporting(E_ALL);
    
    // "1.zad";
    // $username = $password = '';
    // if($_SERVER['REQUEST_METHOD']==='POST'){
    //     setcookie('username', $_POST['username'], time()+5);
    //     setcookie('password', $_POST['password'], time()+5);
    //     $username = $_COOKIE['username'];
    //     $password = $_COOKIE['password'];
    // } else {
    //     if(isset($_POST['username']) || isset($_POST['password'])){
    //         $username = $_COOKIE['username'];
    //         $password = $_COOKIE['password'];
    //     } else {
    //         header('Location: index.php');
    //     }
    // }
    
    // 2. zad
    // session_start([
    //     'cookie_lifetime' => 5,
    // ]);

    // if($_SERVER['REQUEST_METHOD']==='POST'){
    //     $_SESSION['username'] = $_POST['username'];
    //     $_SESSION['password'] = $_POST['password'];
    // }

    // if(!isset($_SESSION['username']) || !isset($_SESSION['password'])){
    //     header('Location: index.php');
    // }

    // $username = $_SESSION['username'];
    // $password = $_SESSION['password'];

    session_start();
    if($_SERVER['REQUEST_METHOD']==='POST'){
        if(!isset($_SESSION['cars'])){
            $_SESSION['cars']=[];
        }
        array_push($_SESSION['cars'], ['brend' => $_POST['brend'], 'model' => $_POST['model'],
        'snaga_motora' => $_POST['snaga_motora'], 'godina_proizvodnje' => $_POST['godina_proizvodnje']]);
    }
?>

<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script> -->
</head>

<body>
    <!-- 1. i 2. zad
    <p>Your Username: <?php //echo $username;?></p>
    <p>Your Password: <?php //echo $password;?></p> -->

    <?php 
        foreach($_SESSION['cars'] as $car){
            $brend = $car['brend'];
            $model = $car['model'];
            $snaga_motora = $car['snaga_motora'];
            $godina_proizvodnje = $car['godina_proizvodnje'];
            echo "<p>Auto</p>";
            echo "<p>Brend: $brend</p>";
            echo "<p>Model: $model</p>";
            echo "<p>Snaga motora: $snaga_motora</p>";
            echo "<p>Godina proizvodnje: $godina_proizvodnje</p>";
        }
    ?>
</body>

</html>