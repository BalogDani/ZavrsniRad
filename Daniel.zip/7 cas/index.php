<?php
    ini_set('display_errors','On');
    error_reporting(E_ALL);
?>

<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script> -->
</head>
<body>
    <!-- 1. i 2. zad
    <form action="/home.php" method="POST">
        <p>Username: <input type="text" name="username" placeholder="Username" required/></p>
        <p>Password: <input type="text" name="password" placeholder="Password" required/></p>
        <input type="submit" name="submit" value="Submit">
    </form> -->
    <form action="/home.php" method="POST">
        <p>Brend: <input type="text" name="brend" placeholder="Mercedes" required/></p>
        <p>Model: <input type="text" name="model" placeholder="A1" required/></p>
        <p>Snaga motora: <input type="text" name="snaga_motora" placeholder='2800'></p>
        <p>Godina proizvodnje: <input type="text" name="godina_proizvodnje" placeholder='2010'></p>
        <input type="submit" name="submit" value="Submit">
    </form>
</body>
</html>