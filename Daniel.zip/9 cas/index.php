<?php
    ini_set('display_errors','On');
    error_reporting(E_ALL);
    class Person {
        public $name;
        public $age;
        public function __construct($name, $age=100) {
            $this->name = $name;
            $this->age = $age;
        }        
        private $id;
        public function setId ($newId) {
            $this->id = $newId;
        }    
    }
    $marko = new Person('Marko');
    //$marko -> name = "Marko";
    //$marko -> age = 30;
    $marko -> setId('ajhfgvj');
    
    // class City{
    //     private $name;
    //     public $population;
    //     public function getName($namuoau){
    //         $this->name=$namuoau;
    //     }
    //     private $green;
    //     public function setGreen ($newGreen) {
    //         $this->green = $newGreen;
    //     }
    // }
    // $noviSad = new City();
    // $noviSad->getName('Novi Sad');
    // $noviSad->population='400000';
    // $noviSad -> setGreen('1/4');

    class City{
        public $name;
        public $population;
        public function __construct($name,$population){
            $this->name=$name;
            $this->population=$population;
        }
    }
    $noviSad = new City('Novi Sad',500000);
    //$noviSad->name='Beograd';

    var_dump($noviSad);

    echo '<br>';
    //$marko -> setCity($noviSad);
    var_dump($marko);

    echo '<br>';
    class Animal{
        public $name;
        private $age;
        public function getAge($godina){
            $this->age=$godina;
        }
        public function __construct($ime){
            $this->name=$ime;
        }
    }

    $myAnimal = new Animal('Tom');
    $myAnimal->name='Thomas';
    $myAnimal->getAge(17);
    var_dump($myAnimal);

    echo "<br>";

    class Pencil{
        public $color;
        private $amount;
        public function setAmount($to){
            $this->amount=$to;
        }
        public function __construct($color, $amount){
            $this->color=$color;
            $this->amount=$amount;
        }
    }

    $myPencil = new Pencil('black',100);
    $myPencil->setAmount(0);
    var_dump($myPencil);
    
    echo "<br>";

    class User{
        public $name;
        public $city;
        public function __construct($name, $city){
            $name = ucfirst($name);
            $this->name=$name;
            $this->city=$city;
        }
    }
    $user = new User('korisnack',$noviSad);
    print_r($user);

    echo "<br>";
    echo "<br>";    

    class Vehicle{
        public $model;
        public $numberOfWheels;
        private $miles;
        public function __construct($model, $numberOfWheels){
            $this->model=$model;
            $this->numberOfWheels=$numberOfWheels;
        }
        public function setMiles($miles){
            $this->miles=$miles;
        }
    }
    $auto = new Vehicle('Fico',4+1/3);
    $auto->setMiles(5000000000);
    print_r($auto);
?>