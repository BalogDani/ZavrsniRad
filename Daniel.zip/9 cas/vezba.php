<?php
    class City{
        
    }
    $noviSad = new City();
?>