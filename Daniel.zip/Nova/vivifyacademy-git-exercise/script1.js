console.log('script 1');

// Da li vidis ovo?
