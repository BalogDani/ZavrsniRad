<?php
    ini_set('display_errors','On');
    error_reporting(E_ALL);

    class Macka {
        public $ime;
        public $majka;
        public $otac;
        public function __construct($ime, $majka='nepoznata', $otac='nepoznat') {
            $this->ime = $ime;
            $this->majka = $majka;
            $this->otac = $otac;
        }
        public function mjau($ime){
            echo $this->ime . " kaze mjau";
        }
    }

    $mjau = new Macka("Maca","Majka");
    $mjau->mjau("Maca");

    echo "<br>";

    $macka = new Macka('Cvrle');
    var_dump($macka);

    class Pravougaonik{
        private $a;
        private $b;
        private $d;

        private function izracunajD(){
            $this -> d = sqrt($this->a *$this->a + $this->b * $this->b);
        }

        public function getA(){
            echo $this->a;
            echo "<br>";
        }
        public function getB(){
            echo $this->b;
            echo "<br>";
        }
        public function getD(){
            echo $this->d;
            echo "<br>";
        }

        public function __construct($a, $b){
            $this -> a = $a;
            $this -> b = $b;
            $this -> d = sqrt($a *$a + $b * $b);
        }

        public function setA($noviA){
            $this -> a = $noviA;
            $this -> izracunajD();
        }
        public function setB($b){
            $this -> b = $b;
            $this -> izracunajD();
        }
    }

    echo "<br>";echo "<br>";

    $pravougaonik = new Pravougaonik(3, 4);
    print_r($pravougaonik);

    echo "<br>";
    $pravougaonik1 = new Pravougaonik(3,8);
    $pravougaonik1->getA();
    $pravougaonik1->setA(5);
    print_r($pravougaonik1);

    echo "<br>";echo "<br>";

    class Racun{
        public $brojRacuna;
        private $banka;
        private $vlasnik;
        private $stanje;
        public function __construct($brojRacuna, $banka, $vlasnik, $stanje){
            $this -> brojRacuna = $brojRacuna;
            $this -> banka = $banka;
            $this -> vlasnik = $vlasnik;
            $this -> stanje = $stanje;
        }
    }

    class Banka{
        public $ime;
        private $racuni = [];
        
        public function dodajRacun($vlasnik, $pocetnoStanje, $brojRacuna){
            $noviRacun = new Racun($brojRacuna, $this->ime, $vlasnik, $pocetnoStanje);
            $this->racuni[] = $noviRacun;
            //array_push($this->racuni, $noviRacun);
            return $this->racuni;
        }

        public function __construct($ime){
            $this->ime = $ime;
        }
    }

    $banka = new Banka("Nesto");
    $banka->dodajRacun("Milos", 5000, 02154421);
    $banka->dodajRacun("Ana", 3500, 35434421);
    var_dump($banka);

    echo "<br>";echo "<br>";

    class SimKartica{
        private $brojTelefona;
        private $mreza;
        public function postaviMrezu($novaMreza){
            $this->mreza = $novaMreza;
        }
        public function __construct($brojTelefona){
            $this->brojTelefona = $brojTelefona;
        }
    }

    class MobilnaMreza{
        public $ime;
        private $sveSimKartice;
        public function __construct($ime)
        {
            $this->ime = $ime;
        }
        public function novaSimKartica($brojTelefona){
            $novaSimKartica = new SimKartica($brojTelefona);
            $novaSimKartica->postaviMrezu($this);
            $this->sveSimKartice[] = $novaSimKartica;
            return $this->sveSimKartice;
        }
    }

    $mts = new MobilnaMreza("mts");
    $mts->novaSimKartica(+381643522);
    $mts->novaSimKartica(+821638472);
    var_dump($mts);

    echo "<br>";echo "<br>";

    class Grad{
        public $ime;
        public function __construct($ime)
        {
            $this->ime = $ime;
        }
    }

    class Igrac{
        public $ime;
        public $prezime;
        public $pozicija;
        public function __construct($ime, $prezime, $pozicija)
        {
            $this->ime = $ime;
            $this->prezime = $prezime;
            $this->pozicija = $pozicija;
        }
    }

    class Klub {
        public $ime;
        public $grad;
        public $datum_osnivanja;
        public $igraci = [];
        public function __construct($ime, $grad, $datum_osnivanja)
        {
            $this->ime = $ime;
            $this->grad = $grad;
            $this->datum_osnivanja = $datum_osnivanja;
        }

        public function dodajIgraca($ime, $prezime, $pozicija){
            $this->igraci[] = new Igrac($ime, $prezime, $pozicija);
        }
    }

    $sakramento = new Grad("Sakramento");
    $kings = new Klub("Kings", $sakramento, 1951);
    $kings->dodajIgraca("Milos", "Milka", 5);
    $kings->dodajIgraca("Ana", "Banana", 7);
    echo '<pre>'; var_dump($kings); echo '</pre>';
    
    echo "<br>";

    class Users{
        private $user;
        private $email;
        private $password;
        public function __construct($user, $email, $password)
        {
            $this->user = $user;
            $this->email = $email;
            $this->password = $password;
        }
    }

    class Profiles{
        private $profile;
        private $user_id;
        public $firstname;
        public $lastname;
        private $city;
        private $date_of_birth;
        private $phone;
        public function __construct($profile, $user_id, $firstname, $lastname, $city, $date_of_birth, $phone)
        {
            $this->profile = $profile;
            $this->user_id = $user_id;
            $this->firstname = $firstname;
            $this->lastname = $lastname;
            $this->city = $city;
            $this->date_of_birth = $date_of_birth;
            $this->phone = $phone;
        }
    }

    class Ad{
        private $ad;
        private $category;
        private $user_id;
        public $title;
        private $content;
        private $created_at;
        private $expires_on;
        public function __construct($ad, $category, $user_id, $title, $content, $created_at, $expires_on)
        {
            $this->ad = $ad;
            $this->category = $category;
            $this->user_id = $user_id;
            $this->title = $title;
            $this->content = $content;
            $this->created_at = $created_at;
            $this->expires_on = $expires_on;
        }
    }

    $user = new Users("marko1", "marko@me.com", "asdasd");
    echo "<pre>"; var_dump($user); echo "</pre>";
    //$profile = new Profiles()
?>