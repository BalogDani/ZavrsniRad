var firstH1Element = document.getElementsByTagName('h1')[0];
console.log(firstH1Element);

firstH1Element.addEventListener('click',abs);
function abs(){
    console.log('gnkdfagk');
}
firstH1Element.removeEventListener('click',abs);

var myDiv = document.querySelector('#myDiv');
myDiv.innerText = 'Daniel';

var myBtn = document.getElementById('myBtn');
myBtn.addEventListener('click',function(){
    myDiv.innerText = 'Novo ime';
})

var user = {
    firstname: 'John',
    lastName: 'Doe'
};
localStorage.setItem('user', JSON.stringify(user));
var storageUser = JSON.parse(localStorage.getItem('user'));
console.log(storageUser);

var unorderedList = document.getElementById('list');
console.log(unorderedList);

prviLi = unorderedList.firstElementChild;
console.log(prviLi);
console.log('\n');

for(var i=0; i<unorderedList.children.length; i++){
    console.log(unorderedList.children[i]);    
}

unorderedList.children[0].textContent = 'First item (edited)';

var noviLi = document.createElement('li');
noviLi.innerHTML = '<h1>Bruce</h1>';
unorderedList.appendChild(noviLi);

// 1. Dodati event listener na <button> element, koji će na klik dugmeta ispisati u konzoli "Button clicked!" (https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener).
var button = document.getElementById('add-new');
button.addEventListener('click',function(){
    console.log("Button clicked!");
});

// 2. Ukucati neki tekst u <input> element, zatim na klik dugmeta ispisati u konzoli tekst koji je unešen (dobija se preko value property-a).
var input = document.querySelector('input');
button.addEventListener('click',function(){
    console.log(input.value);
    
})

// 3. Na klik <button> elementa napraviti novi <li> element, kao innerHTML mu postaviti trenutnu vrednost <input> elementa, i dodati ga kao child <ul> elementa pomoću appendChild (https://developer.mozilla.org/en-US/docs/Web/API/Node/appendChild). 
// button.addEventListener('click',function(){
//     var lee = document.createElement('li');
//     lee.innerHTML = input.value;
//     unorderedList.appendChild(lee);
// });

// 4. Izmeniti kod iz prethodnog zadatka tako da se nakon dodavanja novog <li> u <ul> brise vrednost <input> elementa.
button.addEventListener('click',function(){
    input.value = '';
});

// 5. Dodati p tag u kojem ce da stoji koliko je korisnik kliknuo puta na button `add-new`. Takodje ako izadjem sa stranice ili otvorim u drugom prozoru, hocu da mi nastavi da racuna tamo gdje je stao, a ne da krene ponovo od 0. Koristiti localStorage
var click = localStorage.getItem('click');
console.log(click);

var p = document.createElement('p');
button.addEventListener('click',function(){
    click++;
    console.log(click);
    localStorage.setItem('click',JSON.stringify(click));
    p.textContent = JSON.parse(localStorage.getItem('click'));
    var lee = document.createElement('li');
    lee.innerHTML = 'Index ' + click;
    unorderedList.appendChild(lee);
});

document.body.appendChild(p);