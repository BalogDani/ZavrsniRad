USE oglasi;
CREATE TABLE Users (
    ID int AUTO_INCREMENT,
    Email varchar(255) NOT NULL,
    Password varchar(255) NOT NULL,
    PRIMARY KEY (ID));
CREATE TABLE Profiles (
    ID int AUTO_INCREMENT,
    user_ID int,
    Phone_number varchar(15) NOT NULL,
    First_name varchar(255),
    Last_name varchar(255),
    Date_of_birth DATETIME,
    Country varchar(255),
    City varchar(255),
    PRIMARY KEY (ID),
    FOREIGN KEY (user_ID) REFERENCES Users(ID));
CREATE TABLE Posts (
    ID int AUTO_INCREMENT,
    user_ID int,
    content varchar(255),
    created_at DATETIME,
    PRIMARY KEY (ID),
    FOREIGN KEY (user_ID) REFERENCES Users(ID));
CREATE TABLE Tag (
    ID int AUTO_INCREMENT,
    Name varchar(255),
    PRIMARY KEY (ID));
CREATE TABLE PostTag (
    ID int AUTO_INCREMENT,
    post_ID int,
    tag_ID int,
    PRIMARY KEY (ID),
    FOREIGN KEY (post_ID) REFERENCES Posts(ID),
    FOREIGN KEY (tag_ID) REFERENCES Tag(ID));
CREATE TABLE coment (
    ID int AUTO_INCREMENT,
    post_ID int,
    User varchar(25),
    Text varchar(255),
    created_at DATETIME,
    PRIMARY KEY (ID),
    FOREIGN KEY (post_ID) REFERENCES Posts(ID));

insert into Users(email, password) values('drugiemail', '654123' );

insert into Profiles values (null, 1, '123321123', 'Vlado', 'Plavo', '2020-11-20', 'Serbia', 'Kraljevo');

select u.ID as ID, u.*, p.* from Users u join Profiles p on p.user_ID = u.ID;

insert into Posts values (null, 1, 'asfgdaghdahger', now());
select * from Users;

select * from Users u left join Posts p on u.ID = p.user_ID;

update Users set email = 'a@gmail.com', password = '11111' where email = 'drugiemail';
select * from Posts p inner join Users u on p.user_ID = u.ID inner join Profiles pr on pr.user_ID = u.ID where p.ID=1;
describe Posts;