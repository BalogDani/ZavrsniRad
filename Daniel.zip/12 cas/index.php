<?php
    ini_set('display_errors','On');
    error_reporting(E_ALL);

    function dump($stvar){
        echo '<pre>';
        var_dump($stvar);
        echo '</pre>';
    }

    class Club {
        private $players = [];
        public function addPlayer(Player $player) {
            $this->players[] = $player;
        }
    }

    class Player {

    }

    class Goalkeeper extends Player {

    }

    $udarnik = new Club();
    $kostolomac = new Goalkeeper();
    $udarnik->addPlayer($kostolomac);

    // dump($udarnik);

    class Disk {
        public $ime;
        public $memorija;
        public $lista_foldera = [];
        public function __construct(string $ime,string $memorija)
        {
            $this->ime = $ime;
            $this->memorija = $memorija;
        }
        public function dodajFolder(Folder $folder)
        {
            $this->lista_foldera[] = $folder;
        }
     }
     class Folder {
        public $ime;
        public $lista_fajlova = [];
        public function __construct(string $ime)
        {
            $this->ime = $ime;
        }
        public function dodajFajl(Fajl $fajl)
        {
            $this->lista_fajlova[] = $fajl;
        }
     }
     abstract class Fajl {
        public $ime;
        private static $brojac;
        abstract public function getTip();
        public function __construct(string $ime)
        {
            self::$brojac++;
            $this->ime = $ime;
        }
        public static function getBrojac(){
            return self::$brojac;
        }
     }
     class Video extends Fajl {
        public $format;
        public function __construct(string $ime, string $format)
        {
            parent::__construct($ime);
            $this->format = $format;
        }
        public function getTip(){
            echo "To<br>";
        }
     }
     class Slika extends Fajl {
        public $sirina;
        public $visina;
        public function __construct(string $ime,string $sirina,string $visina)
        {
            parent::__construct($ime);
            $this->sirina = $sirina;
            $this->visina = $visina;
        }
        public function getTip(){
            echo "To<br>";
        }
     }
     class TekstualniFajl extends Fajl {
        public $duzinaTeksta;
        public function __construct(string $ime,string $duzinaTeksta)
        {
            parent::__construct($ime);
            $this->duzinaTeksta = $duzinaTeksta;
        }
        public function getTip(){
            echo "To<br>";
        }
     }
     $cDisk = new Disk('c', 5000);
     $folderSlike = new Folder('Slike');
     $folderVideo = new Folder('Video');
     $folderText = new Folder('Text');
     $cDisk->dodajFolder($folderSlike);
     $cDisk->dodajFolder($folderVideo);
     $cDisk->dodajFolder($folderText);
     $slika1 = new Slika('Leto 2017', 800, 600);
     $slika2 = new Slika('Leto 2016', 800, 600);
     $folderSlike->dodajFajl($slika1);
     $folderSlike->dodajFajl($slika2);
     $video1 = new Video('Utakmica', 'mp4');
     $folderVideo->dodajFajl($video1);
     $textualniFajl1 = new TekstualniFajl('Dokument1', 3000);
     $textualniFajl2 = new TekstualniFajl('Dokument2', 5000);
     $folderText->dodajFajl($textualniFajl1);
     $folderText->dodajFajl($textualniFajl2);
    //  dump($cDisk);
     dump("Ukupno ". Fajl::getBrojac() . " fajlova imamo.");
     $textualniFajl1->getTip();

     class GeometrijskiObjekat {
        public $povrsina;
        static public $brojacOsnovni;
        public function __construct($povrsina)
        {
            self::$brojacOsnovni++;
            $this->povrsina = $povrsina;
        }
        public function getPovrsina() :int
        {
            return $this->povrsina;
        }
        
    }
    class Objekat2D extends GeometrijskiObjekat {
        public $obim;
        static private $brojac;
        public function __construct($povrsina, $obim)
        {
            self::$brojac++;
            parent::__construct($povrsina);
            $this->obim = $obim;
        }
        public function getObim() :int
        {
            return $this->obim;
        }
        public static function getBrojac(){
            return self::$brojac;
        }
    }
    class Objekat3D extends GeometrijskiObjekat {
        public $zapremina;
        static private $brojac;
        public function __construct($povrsina, $zapremina)
        {
            self::$brojac++;
            parent::__construct($povrsina);
            $this->zapremina = $zapremina;
        }
        public function getZapremina() :int
        {
            return $this->zapremina;
        }
        public static function getBrojac(){
            return self::$brojac;
        }
        public static function getOsnovniBrojac(){
            return self::$brojacOsnovni;
        }
    }
    class Pravougaonik extends Objekat2D {
        public $a;
        public $b;
        public function __construct($a, $b)
        {
            $povrsina = $a * $b;
            $obim = 2 * ($a+$b);
            parent::__construct($povrsina, $obim);
            $this->a = $a;
            $this->b = $b;
        }
    }
    class Kvadrat extends Pravougaonik {
        public function __construct($stranica)
        {
            parent::__construct($stranica, $stranica);
        }
    }
    class Krug extends Objekat2D {
        public $poluprecnik;
        public function __construct($poluprecnik)
        {
            $povrsina = $poluprecnik * $poluprecnik * 3.14;
            $obim = 2 * $poluprecnik * 3.14;
            parent::__construct($povrsina, $obim);
            $this->poluprecnik = $poluprecnik;
        }
    }
    class Lopta extends Objekat3D {
        public $poluprecnik;
        public function __construct($poluprecnik)
        {
            $povrsina = 4 * $poluprecnik * $poluprecnik * 3.14;
            $zapremina = (4 / 3) * $poluprecnik  * $poluprecnik * $poluprecnik * 3.14;
            parent::__construct($povrsina, $zapremina);
            $this->poluprecnik = $poluprecnik;
        }
    }
    class Kocka extends Objekat3D {
        public $stranica;
        public function __construct($stranica)
        {
            $povrsina = 6 * $stranica * $stranica;
            $zapremina = $stranica * $stranica * $stranica;
            parent::__construct(
                $povrsina,
                $zapremina
            );
            $this->stranica = $stranica;
        }
    }
     $kv1 = new Kvadrat(5);
    //  echo "Povrsina kvadrata je: " . $kv1->getPovrsina() . "<br/>";
    //  echo "Obim kvadrata je: " . $kv1->getObim() . "<br/>";
     $pu1 = new Pravougaonik(4,5);
    //  echo "Povrsina pravougaonika je: " . $pu1->getPovrsina() . "<br/>";
    //  echo "Obim pravougaonika je: " . $pu1->getObim() . "<br/>";
     $kc1 = new Kocka(3);
    //  echo "Povrsina kocke je: " . $kc1->getPovrsina() . "<br/>";
    //  echo "Zapremina kocke je: " . $kc1->getZapremina() . "<br/>";
    echo "Imamo " . Objekat2D::getBrojac() . " 2D geom. objekata.<br>";
    echo "Imamo " . Objekat3D::getBrojac() . " 3D geom. objekata.<br>"; 
    echo "A ukupno imamo " . Objekat3D::getOsnovniBrojac() . " geom. objekata.<br><br>"; 
    
     class Product{
         public static $count = 0;
         public $name;

         public function __construct($productName){
             self::$count++;
             $this->name = $productName;
             echo "Produced so far: " . self::$count . '<br>' . $this->name . "<br>";
         }

         public static function getCount(){
             return self::$count;
         }
     }

     $milk = new Product('Milk');
     $bread = new Product('Bread');

     echo "Total number of created products is: " . Product::$count . "<br>";

     abstract class Animal{
         public $name;
         public abstract function speak();
         public function getName(){
             return $this->name;
         }
     }
     class Dog extends Animal{
         public function __construct($name){
             $this->name = $name;
         }
         public function speak()
         {
             echo "Vau";
         }
     }

     $Snoopy = new Dog('Snoopy');
     $Snoopy->speak();

     interface Paintable{
         public function setColor($color);
         public function getColor();
     }
     class Car implements Paintable{
         public $color = 'red';
         public function setColor($color){
             $this->color = $color;
         }
         public function getColor(){
             return $this->color;
         }
     }
     class Painter{
         public function paint(Paintable $paintable, $color){
             $paintable->setColor($color);
         }
     }

    $car = new Car();
    $car->setColor('green');
    $painter = new Painter();
    $painter->paint($car, 'blue');
    dump($car->getColor());

    interface Prenosivo{
        public function spakuj($string);
        public function prenesi($pozicija);
        public function raspakuj($string);
    }
    class Racunar implements Prenosivo{
        public $brend;
        public $pozicija = 'Nema';
        public function spakuj($string){
            echo $string;
        }
        public function prenesi($pozicija){
            $this->pozicija = $pozicija;
        }
        public function raspakuj($string){
            echo $string;
        }
    }
    class Krevet implements Prenosivo{
        public $brend;
        public $pozicija = 'Nema';
        public function spakuj($string){
            echo $string;
        }
        public function prenesi($pozicija){
            $this->pozicija = $pozicija;
        }
        public function raspakuj($string){
            echo $string;
        }
    }

    $hp = new Racunar();
    $krevet = new Krevet();
    $hp->brend = 'hp';
    echo $hp->spakuj('Spakuj');
    $hp->prenesi('Nova pozicija');
    echo $hp->raspakuj('Raspakuj');
    dump($hp);
?>