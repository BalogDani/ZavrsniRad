<?php
function prva($a,$b,$c){
    if($a>0){
        echo $b + $c . '<br>';
    } else {
        echo $b - $c . '<br>';
    }
}
prva(2,4,5);
prva(-1,4,5);

echo "<br>";

function druga($niz, $donjaGranica, $gornjaGranica){
    $odgovor = true;
    foreach ($niz as $broj) {
        if($donjaGranica > $broj && $gornjaGranica < $broj){
            $odgovor = false;
            break;
        }
    }
    return $odgovor;
}

var_dump(druga([1,4,5,7],0,9));
var_dump(druga([1,4,5,7],2,9));