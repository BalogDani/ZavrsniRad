<?php 
    ini_set('display_errors','On');
    error_reporting(E_ALL);
    $poruka = 'Hello there';
    // $link = ["https://google.com","Google"];

    $niz = [
        'list' => 'To do',
        'items' => [
        ['title' => 'Buy groceries','link'=>'https://google.com'],
        ['title' => 'Return books'],
        ['title' =>  'Fix the light']
        ]
    ];
?>

<!DOCTYPE html>
    <html>

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Nasa stranica</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
        <script src="main.js"></script>
    </head>

    <body>
        <h3><?php echo $niz['list'];?></h3>
        <ul>
            <?php 
                foreach($niz['items'] as $element){
                    $title = $element['title'];
                    $output = "Naziv $title";

                    if(isset($element['link'])){
                        $link = $element['link'];
                        $output .= ", Link: <a href='$link'>$title</a>";
                    } 
                    
                    echo "<li>$output</li>";
                    
                }
            ?>
        </ul>
    </body>

    </html>