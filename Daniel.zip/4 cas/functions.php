<?php 
    function getFavoriteVideos($videos){
        return array_filter($videos, function($video){
            return $video['isFavorite'];
        });
    } 
    
    function getNotFavoriteVideos($videos){
        return array_filter($videos, function($video){
            return !$video['isFavorite'];
        });
    } 
?>